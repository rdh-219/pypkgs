# X-Ray Analyzer Android App

Complete Android Studio project for Android 10+ that uploads a chest X-ray image to your FastAPI TorchXRayVision backend and displays pathology probabilities.

## Requirements

- Android Studio Koala or newer recommended
- JDK 17
- Android device/emulator with Android 10+ / API 29+
- Running FastAPI backend from `xray_fastapi_backend_complete.zip`

## Project settings

- Min SDK: 29 / Android 10
- Target SDK: 35
- Language: Kotlin
- UI: Native Android XML + Material Components
- Network: Retrofit + OkHttp

## Backend URL

Default URL in emulator:

```text
http://10.0.2.2:8000/
```

Use this when the FastAPI backend runs on the same PC as Android Emulator.

For a real Android phone, use your PC/server LAN IP, for example:

```text
http://192.168.1.50:8000/
```

Your phone and backend server must be on the same network, and firewall must allow TCP port 8000.

## Expected backend endpoint

The app calls:

```text
POST /predict
multipart/form-data:
  file: image file
  threshold: 0.5
```

Expected JSON shape:

```json
{
  "filename": "sample.png",
  "model": "densenet121-res224-all",
  "device": "cpu",
  "threshold": 0.5,
  "predictions": {
    "Atelectasis": 0.12,
    "Cardiomegaly": 0.05
  },
  "positive_findings": {},
  "report": "Optional report text"
}
```

## How to open

1. Extract this ZIP.
2. Open Android Studio.
3. Choose **Open**.
4. Select the `xray_android_app` folder.
5. Let Gradle sync.
6. Run the app.

## How to test with emulator

1. Start your FastAPI backend:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

2. In Android app, keep server URL:

```text
http://10.0.2.2:8000/
```

3. Select an X-ray image.
4. Press **Analyze**.

## How to build APK

In Android Studio:

```text
Build > Build Bundle(s) / APK(s) > Build APK(s)
```

Or command line:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

Note: this ZIP does not include Gradle wrapper binaries. Android Studio can use installed Gradle automatically, or you can add wrapper files using:

```bash
gradle wrapper --gradle-version 8.7
```

## Medical safety warning

This application is for research and education only. It is not a medical device and does not provide diagnosis. All results must be reviewed by a licensed doctor or radiologist.
