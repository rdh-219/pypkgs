package com.example.xrayanalyzer

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.xrayanalyzer.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val adapter = ResultAdapter()
    private var selectedUri: Uri? = null
    private var selectedFile: File? = null

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            binding.xrayImageView.setImageURI(uri)
            binding.analyzeButton.isEnabled = true
            binding.statusTextView.text = "Image selected. Press Analyze."
            binding.reportTextView.text = ""
            adapter.submitList(emptyList())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.resultsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.resultsRecyclerView.adapter = adapter

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val savedUrl = prefs.getString("server_url", "http://10.0.2.2:8000/") ?: "http://10.0.2.2:8000/"
        binding.serverUrlEditText.setText(savedUrl)

        binding.saveServerButton.setOnClickListener {
            val normalized = normalizeBaseUrl(binding.serverUrlEditText.text.toString())
            binding.serverUrlEditText.setText(normalized)
            prefs.edit().putString("server_url", normalized).apply()
            Toast.makeText(this, "Server URL saved", Toast.LENGTH_SHORT).show()
        }

        binding.selectImageButton.setOnClickListener {
            imagePicker.launch("image/*")
        }

        binding.analyzeButton.setOnClickListener {
            analyzeSelectedImage()
        }
    }

    private fun analyzeSelectedImage() {
        val uri = selectedUri
        if (uri == null) {
            Toast.makeText(this, "Please select an X-ray image first", Toast.LENGTH_SHORT).show()
            return
        }

        val baseUrl = normalizeBaseUrl(binding.serverUrlEditText.text.toString())
        binding.serverUrlEditText.setText(baseUrl)
        getSharedPreferences("settings", MODE_PRIVATE).edit().putString("server_url", baseUrl).apply()

        setLoading(true)
        binding.statusTextView.text = "Uploading image and waiting for AI result..."
        binding.reportTextView.text = ""
        adapter.submitList(emptyList())

        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) { FileUtils.copyUriToCache(this@MainActivity, uri) }
                selectedFile = file
                val api = createApi(baseUrl)
                val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
                val body = MultipartBody.Part.createFormData("file", file.name, requestFile)
                val threshold = "0.5".toRequestBody("text/plain".toMediaTypeOrNull())

                val response = withContext(Dispatchers.IO) { api.predict(body, threshold) }
                if (response.isSuccessful) {
                    val result = response.body()
                    if (result != null) showResult(result) else showError("Server returned an empty response")
                } else {
                    val errorText = response.errorBody()?.string() ?: "Unknown server error"
                    showError("HTTP ${response.code()}: $errorText")
                }
            } catch (e: Exception) {
                showError(e.message ?: e.toString())
            } finally {
                setLoading(false)
            }
        }
    }

    private fun showResult(result: PredictionResponse) {
        val sorted = result.predictions.entries
            .map { ResultItem(it.key, it.value) }
            .sortedByDescending { it.score }

        adapter.submitList(sorted)

        val top = sorted.take(5).joinToString(separator = "\n") {
            String.format(Locale.US, "- %s: %.1f%%", it.name, it.score * 100.0)
        }

        val serverReport = result.report?.takeIf { it.isNotBlank() }
        val report = buildString {
            appendLine("Top predicted findings:")
            appendLine(top.ifBlank { "No predictions returned." })
            appendLine()
            if (serverReport != null) {
                appendLine("Backend report:")
                appendLine(serverReport)
            } else {
                appendLine("This result is a probability ranking only. It is not a diagnosis.")
            }
        }

        binding.statusTextView.text = "Analysis complete. Model: ${result.model ?: "unknown"}, device: ${result.device ?: "unknown"}"
        binding.reportTextView.text = report
    }

    private fun showError(message: String) {
        binding.statusTextView.text = "Error: $message"
        Toast.makeText(this, "Analysis failed", Toast.LENGTH_LONG).show()
    }

    private fun setLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) android.view.View.VISIBLE else android.view.View.GONE
        binding.analyzeButton.isEnabled = !isLoading && selectedUri != null
        binding.selectImageButton.isEnabled = !isLoading
        binding.saveServerButton.isEnabled = !isLoading
    }

    private fun normalizeBaseUrl(input: String): String {
        var url = input.trim()
        if (url.isBlank()) url = "http://10.0.2.2:8000/"
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://$url"
        if (!url.endsWith("/")) url += "/"
        return url
    }

    private fun createApi(baseUrl: String): ApiService {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
