package com.example.xrayanalyzer

import com.google.gson.annotations.SerializedName

data class PredictionResponse(
    @SerializedName("filename") val filename: String? = null,
    @SerializedName("model") val model: String? = null,
    @SerializedName("device") val device: String? = null,
    @SerializedName("threshold") val threshold: Double? = null,
    @SerializedName("predictions") val predictions: Map<String, Double> = emptyMap(),
    @SerializedName("positive_findings") val positiveFindings: Map<String, Double>? = null,
    @SerializedName("report") val report: String? = null
)

data class ResultItem(
    val name: String,
    val score: Double
)
