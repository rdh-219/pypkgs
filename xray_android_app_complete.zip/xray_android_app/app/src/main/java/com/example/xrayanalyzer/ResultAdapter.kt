package com.example.xrayanalyzer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.xrayanalyzer.databinding.ItemResultBinding
import java.util.Locale

class ResultAdapter : RecyclerView.Adapter<ResultAdapter.ResultViewHolder>() {
    private val items = mutableListOf<ResultItem>()

    fun submitList(newItems: List<ResultItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
        val binding = ItemResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        holder.bind(items[position])
    }

    class ResultViewHolder(private val binding: ItemResultBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ResultItem) {
            val percent = (item.score * 100.0).coerceIn(0.0, 100.0)
            binding.pathologyTextView.text = item.name
            binding.scoreTextView.text = String.format(Locale.US, "%.1f%%", percent)
            binding.scoreProgressBar.progress = percent.toInt()
        }
    }
}
